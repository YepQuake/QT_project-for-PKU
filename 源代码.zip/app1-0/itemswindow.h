#ifndef ITEMSWINDOW_H
#define ITEMSWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <map>
#include <utility>

namespace Ui {
class ItemsWindow;
}

class ItemsWindow : public QMainWindow
{
    Q_OBJECT

public:
    ItemsWindow(QWidget *parent = nullptr);
    ~ItemsWindow();

    void buildTreeview(std::multimap<std::pair<int,int>,std::pair<int,QString>> loc,QString item_name);

    std::pair<int,int> string_to_int(QString s);

signals:
    void sendData(int pre_parent,int pre_kid,int pro_parent,int pro_kid,int number,QString name);

    void sendData2(int pre_parent,int pre_kid,QString pro_parent,QString pro_kid,int number,QString name);

private slots:
    void on_delitems_clicked();

    void on_moveitems_clicked();


private:
    Ui::ItemsWindow *ui;
    QStandardItemModel * my_pmodel2;
};

#endif // ITEMSWINDOW_H

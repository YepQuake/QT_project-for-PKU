#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "additemsdlg.h"
#include "itemswindow.h"
#include <QDate>
#include <QMessageBox>
#include <QDebug>
#include <QVBoxLayout>
#include <QLabel>
#include <map>
#include <utility>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //此处为window的构造函数

    ui->setupUi(this);

    //设置窗口标题名称
    this->setWindowTitle("物品分类管理系统");

    //禁用最大化按钮
    this->setWindowFlags(windowFlags() & ~Qt::WindowMaximizeButtonHint);

    //建立数据模型对象空间
    my_pmodel=new QStandardItemModel(ui->treeView);

    //将数据模型设置到树形控件视图上
    ui->treeView->setModel(my_pmodel);

    //设置水平表头列平均分
    ui->treeView->header()->setSectionResizeMode(QHeaderView::Stretch);

    //添加控件标题名称
    my_pmodel->setHorizontalHeaderLabels(QStringList()<<"地点名称");

    QList <QStandardItem*> toplist;
    toplist<<new QStandardItem("回收站");
    toplist[0]->setData(-1,Qt::UserRole+1);
    my_pmodel->appendRow(toplist);

    QList <QStandardItem*> toplist1;
    toplist1<<new QStandardItem("运输途中");
    toplist1[0]->setData(-1,Qt::UserRole+1);
    my_pmodel->appendRow(toplist1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_addnode_clicked()
{
    //添加父节点
    int idxnum=my_pmodel->rowCount();//序号
    QList <QStandardItem*> toplist;
    QString obj_name=ui->lineofdadnodename->text();
    toplist<< new QStandardItem(obj_name);
    ui->lineofdadnodename->setText(0);

    //设置一级节点
    toplist[0]->setData(-1,Qt::UserRole+1);

    //添加一级节点
    my_pmodel->appendRow(toplist);
}//新建父节点


void MainWindow::on_addkidnode_clicked()
{
    //添加子节点

    //获取当前行列
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int icol=currentIndex.column();
    int iparentrow=currentIndex.data(Qt::UserRole+1).toInt();
    //下面的if是用于判断什么情况下不能添加子节点的
    if(irow==-1||icol==-1||iparentrow!=-1){
        return;
    }
    if(iparentrow==-1&&(irow==0||irow==1)){
        return;
    }
    QStandardItem *currentTopItem=my_pmodel->item(irow);
    QList <QStandardItem*> childlist;
    QString obj_name=ui->lineofsonnodename->text();
    ui->lineofsonnodename->setText(0);
    childlist<<new QStandardItem (obj_name);
    childlist[0]->setData(irow,Qt::UserRole+1);
    currentTopItem->appendRow(childlist);
}//新建子节点


void MainWindow::on_delnode_clicked()
{
    //获取当前行列
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int icol=currentIndex.column();
    int iparentrow=currentIndex.data(Qt::UserRole+1).toInt();
    if(irow==-1||icol==-1){
        return;
    }

    if(-1==iparentrow){
        my_pmodel->removeRow(irow);
    }
    else
    {
        QStandardItem*  parentItem=my_pmodel->item(iparentrow);
        parentItem->removeRow(irow);
    }

}//删除节点


void MainWindow::on_getcurrentnode_clicked()
{
    std::vector<Item> searched;
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int sirow=currentIndex.row();
    int sicol=currentIndex.column();
    int siparentrow=currentIndex.data(Qt::UserRole+1).toInt();
    if(sirow==-1&&sicol==-1){
        return;
    }
    for(int i=0;i<int(items.size());i++){
        if(items[i].irow==sirow&&items[i].iparentrow==siparentrow){
            searched.push_back(items[i]);
        }
    }
    if (searched.size() > 0) {
        QDialog *dialog = new QDialog(this);
        dialog->setWindowTitle("物品信息");
        QVBoxLayout *mainLayout = new QVBoxLayout(dialog);
        for (const auto &item : searched) {
            QHBoxLayout *itemLayout = new QHBoxLayout;
            QString itemInfo = QString("Name: %1  Number: %2  Price: %3  Expiration Date: %4  Tip: %5")
                                   .arg(item.name)
                                   .arg(item.number)
                                   .arg(item.price)
                                   .arg(item.exp)
                                   .arg(item.tip);

            QLabel *label = new QLabel(itemInfo);
            itemLayout->addWidget(label);
            mainLayout->addLayout(itemLayout);
        }

        dialog->setLayout(mainLayout);
        dialog->exec();
        delete dialog;
    } else {
        QMessageBox::information(this, "No Items Found", "No items found matching the selected criteria.");
    }

}


void MainWindow::on_modifycurrentnode_clicked()
{
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int icol=currentIndex.column();
    int iparentrow=currentIndex.data(Qt::UserRole+1).toInt();
    if(irow==-1||icol==-1){
        return;
    }
    if(iparentrow==-1){
        QStandardItem*  parentItem=my_pmodel->item(irow);
        QString obj_name=ui->lineofmodifynodename->text();
        ui->lineofmodifynodename->setText(0);
        parentItem->setText(obj_name);
    }
    else{
        QString obj_name=ui->lineofmodifynodename->text();
        ui->lineofmodifynodename->setText(0);
        QStandardItem* kidItem=my_pmodel->item(iparentrow)->child(irow);
        kidItem->setText(obj_name);
    }

}//修改节点



void MainWindow::on_additemstocurrentnode_clicked()
{
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int icol=currentIndex.column();
    if(irow==-1||icol==-1){
        return;
    }
    else{
        dlg1=new AdditemsDlg(this);
        //关联子界面信号和槽函数
        connect(dlg1,SIGNAL(mvsigData(QString,int,double,QString,QString)),this,SLOT(receiveData(QString,int,double,QString,QString)));
        dlg1->show();
    }
}//添加物品

void MainWindow::receiveData(QString sname,int snumber,double sprice,QString sexp,QString stip){
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int iparentrow=currentIndex.data(Qt::UserRole+1).toInt();
    items.push_back(Item(sname,snumber,sprice,sexp,stip,irow,iparentrow));
}


void MainWindow::on_searchitems_clicked()
{
    QString item_name=ui->lineofsearch->text();
    ui->lineofsearch->setText(0);
    std::multimap<std::pair<int,int>,std::pair<int,QString>> loc;
    for(int i=0;i<int(items.size());i++){
        if(items[i].name==item_name){
            QString loc_name;
            if(items[i].iparentrow==-1){
                QStandardItem*  parentItem=my_pmodel->item(items[i].irow);
                loc_name=parentItem->text();
            }
            else{
                QStandardItem* kidItem=my_pmodel->item(items[i].iparentrow)->child(items[i].irow);
                loc_name=kidItem->text();
            }
            loc.insert(std::make_pair(std::make_pair(items[i].iparentrow,items[i].irow),std::make_pair(items[i].number,loc_name)));
        }
    }
    if(loc.empty()){
        QMessageBox::information(this, "No Items Found", "No items found matching the selected criteria.");
    }
    else{
        iw=new ItemsWindow(this);
        iw->buildTreeview(loc,item_name);
        connect(iw,SIGNAL(sendData(int,int,int,int,int,QString)),this,SLOT(receiveData2(int,int,int,int,int,QString)));
        connect(iw,SIGNAL(sendData2(int,int,QString,QString,int,QString)),this,SLOT(receiveData3(int,int,QString,QString,int,QString)));
        iw->show();
    }
}

void MainWindow::receiveData2(int pre_parent,int pre_kid,int pro_parent,int pro_kid,int number,QString name){
    if(number==0){
        QMessageBox::information(this, "操作失败", "转移数量不能为0");
        return;
    }
    int pre,pro;
    for(int i=0;i<items.size();i++){
        if(items[i].iparentrow==pre_parent&&items[i].irow==pre_kid&&items[i].name==name){
            if(items[i].number<number){
                QMessageBox::information(this, "操作失败", "可转移数量不足");
                return;
            }
            else pre=i;
            break;
        }
    }
    if(pre_parent==-1&&pre_kid==0&&pro_parent==-1&&pro_kid==0){
        items[pre].number-=number;
        if(items[pre].number==0){
            std::vector<Item>::iterator p=items.begin()+pre;
            items.erase(p);
        }
        QMessageBox::information(this, "操作完成", "成功转移物品");
        return;
    }
    bool flag=1;
    for(int i=0;i<items.size();i++){
        if(items[i].iparentrow==pro_parent&&items[i].irow==pro_kid&&items[i].name==name&&items[i].price==items[pre].price&&items[i].exp==items[pre].exp&&items[i].tip==items[pre].tip){
            flag=0;
            pro=i;
            break;
        }
    }
    if(flag){
        items.push_back(Item(name,number,items[pre].price,items[pre].exp,items[pre].tip,pro_kid,pro_parent));
    }
    else{
        items[pro].number+=number;
    }
    items[pre].number-=number;
    if(items[pre].number==0){
        std::vector<Item>::iterator p=items.begin()+pre;
        items.erase(p);
    }
    QMessageBox::information(this, "操作完成", "成功转移物品");
}

void MainWindow::receiveData3(int pre_parent,int pre_kid,QString pro_parent,QString pro_kid,int number,QString name){
    int pro_p,pro_k;
    bool flag=0;
    if(number==0){
        QMessageBox::information(this, "操作失败", "转移数量不能为0");
        return;
    }
    if(pro_parent.size()==0){
        QMessageBox::information(this, "操作失败", "查询不到该地点");
        return;
    }
    if(pro_kid.size()==0){
        int idxnum=my_pmodel->rowCount();
        for(int i=0;i<idxnum;i++){
            if(my_pmodel->item(i)->text()==pro_parent){
                flag=1;
                pro_p=-1;
                pro_k=i;
                break;
            }
        }
    }
    else{
        for(int i=0;i<my_pmodel->rowCount();i++){
            if(my_pmodel->item(i)->text()==pro_parent){
                pro_p=i;
                for(int j=0;j<my_pmodel->item(i)->rowCount();j++){
                    if(my_pmodel->item(i)->child(j)->text()==pro_kid){
                        flag=1;
                        pro_k=j;
                        break;
                    }
                }
                break;
            }

        }
    }
    if(!flag){
        QMessageBox::information(this, "操作失败", "查询不到该地点");
    }
    else{
        receiveData2(pre_parent,pre_kid,pro_p,pro_k,number,name);
    }
}


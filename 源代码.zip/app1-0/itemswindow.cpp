#include "itemswindow.h"
#include "ui_itemswindow.h"

ItemsWindow::ItemsWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ItemsWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("查询结果");
    my_pmodel2=new QStandardItemModel(ui->treeView);
    ui->treeView->setModel(my_pmodel2);
    ui->treeView->header()->setSectionResizeMode(QHeaderView::Stretch);
    my_pmodel2->setHorizontalHeaderLabels(QStringList()<<"地点名称"<<"数量"<<"物品名称");
}

ItemsWindow::~ItemsWindow()
{
    delete ui;
}

void ItemsWindow::on_delitems_clicked()
{
    int number=ui->spinBox->value();
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int pre_row,pre_parentrow;
    QString pre_loc=my_pmodel2->item(irow,0)->text();
    if(pre_loc[0]=='R'){
        pre_parentrow=-1;
        pre_row=0;
    }
    else if(pre_loc[0]=='E'){
        pre_parentrow=-1;
        pre_row=1;
    }
    else{
        pre_parentrow=string_to_int(pre_loc).first;
        pre_row=string_to_int(pre_loc).second;
    }
    emit sendData(pre_parentrow,pre_row,-1,0,number,my_pmodel2->item(irow,2)->text());
}


void ItemsWindow::on_moveitems_clicked()
{
    int number=ui->spinBox->value();
    QModelIndex currentIndex=ui->treeView->currentIndex();
    int irow=currentIndex.row();
    int pre_row,pre_parentrow;
    QString pre_loc=my_pmodel2->item(irow,0)->text();
    if(pre_loc[0]=='R'){
        pre_parentrow=-1;
        pre_row=0;
    }
    else if(pre_loc[0]=='E'){
        pre_parentrow=-1;
        pre_row=1;
    }
    else{
        pre_parentrow=string_to_int(pre_loc).first;
        pre_row=string_to_int(pre_loc).second;
    }
    QString pro_parent=ui->lineofparent->text();
    QString pro_kid=ui->lineofchild->text();
    emit sendData2(pre_parentrow,pre_row,pro_parent,pro_kid,number,my_pmodel2->item(irow,2)->text());
}

void ItemsWindow::buildTreeview(std::multimap<std::pair<int,int>,std::pair<int,QString>> loc,QString item_name){
    typedef std::multimap<std::pair<int,int>,std::pair<int,QString>> Mp;
    Mp::iterator p=loc.begin();
    for(;p!=loc.end();p++){
        QList <QStandardItem*> toplist;
        if(p->first.first==-1){
            if(p->first.second==0){
                toplist<< new QStandardItem("RCC. "+p->second.second);
            }
            else if(p->first.second==1){
                toplist<< new QStandardItem("EX. "+p->second.second);
            }
            else{
                toplist<< new QStandardItem(QString("%1").arg(p->first.second-1)+". "+p->second.second);
            }
        }
        else{
            toplist<< new QStandardItem(QString("%1").arg(p->first.first-1)+"-"+QString("%1").arg(p->first.second+1)+". "+p->second.second);
        }
        toplist<<new QStandardItem(QString("%1").arg(p->second.first));
        toplist<<new QStandardItem(item_name);
        toplist[0]->setData(-1,Qt::UserRole+1);
        my_pmodel2->appendRow(toplist);
    }
}

std::pair<int,int> ItemsWindow::string_to_int(QString s){
    int parent,kid;
    bool flag=1;
    for(int i=0;i<s.length();i++){
        if(s[i]=='.')
            break;
        if(s[i]=='-')
            flag=0;
    }
    if(flag){
        parent=-1;
        kid=0;
        for(int i = 0; i < s.length(); i++) {
            if(s[i]=='.')
                break;
            kid = kid*10 + int(s[i].toLatin1()-'0');
        }
        return std::make_pair(parent,kid+1);
    }
    else{
        parent=kid=0;
        int tag=0;
        for(int i = 0; i < s.length(); i++) {
            if(s[i]=='-'){
                tag=i+1;
                break;
            }
            parent = parent*10 + int(s[i].toLatin1()-'0');
        }
        for(int i = tag; i < s.length(); i++) {
            if(s[i]=='.')
                break;
            kid = kid*10 + int(s[i].toLatin1()-'0');
        }
        return std::make_pair(parent+1,kid-1);
    }
}


